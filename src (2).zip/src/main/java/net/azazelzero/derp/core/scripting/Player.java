package net.azazelzero.derp.core.scripting;

public class Player {


    public Player(){

    }


    public void printToConsole(){
        System.out.println("Hello World from java");
    }


}
