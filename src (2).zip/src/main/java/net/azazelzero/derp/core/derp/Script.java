package net.azazelzero.derp.core.derp;

public class Script {
    public final String ID;
    public final String Script;

    public Script(String id, String script) {
        ID = id;
        Script = script;
    }
}
