package net.azazelzero.derp.core.derp;

public enum SkillBoolean {
    Unlocked,
    Locked,
    Unset
}
